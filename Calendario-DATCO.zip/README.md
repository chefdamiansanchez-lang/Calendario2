# Calendario DATCO
Calendario con agenda por día y alarmas de recordatorio. Abre con el splash de DATCO.
Al subir el proyecto a GitHub, el workflow compila el APK (pestaña Actions > Artifacts).
