package com.datco.calendario

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import kotlin.random.Random

fun estacion(m0: Int): String = when (m0) {
    11, 0, 1 -> "verano"
    2, 3, 4 -> "otoño"
    5, 6, 7 -> "invierno"
    else -> "primavera"
}

fun acento(m0: Int): Color = when (estacion(m0)) {
    "verano" -> Color(0xFFFF8A00)
    "otoño" -> Color(0xFFE8590C)
    "invierno" -> Color(0xFF1C7ED6)
    else -> Color(0xFFE64980)
}

// Cielo de cada mes (0 = enero)
val SKY = listOf(
    Color(0xFF6CCBFF), Color(0xFF9AE0F5), Color(0xFFFFE3B3), Color(0xFFFFD9A0),
    Color(0xFFFFCFA8), Color(0xFFBFE0FF), Color(0xFFCFE7FF), Color(0xFFB5D9F8),
    Color(0xFFBDEBFF), Color(0xFFC8F0FF), Color(0xFFD4F5E9), Color(0xFF8EDBFF)
)

fun DrawScope.drawScene(m0: Int) {
    val r = Random(m0 * 97 + 13)
    drawRect(SKY[m0])
    when (estacion(m0)) {
        "verano" -> verano(m0, r)
        "otoño" -> otono(m0, r)
        "invierno" -> invierno(m0, r)
        else -> primavera(m0, r)
    }
}

private fun DrawScope.colina(color: Color, y: Float, bulge: Float) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(0f, h)
        lineTo(0f, y)
        quadraticBezierTo(w * 0.5f, y - bulge * h, w, y + 0.02f * h)
        lineTo(w, h)
        close()
    }
    drawPath(p, color)
}

private fun DrawScope.verano(m0: Int, r: Random) {
    val w = size.width
    val h = size.height
    val sunX = when (m0) { 11 -> 0.2f; 0 -> 0.5f; else -> 0.8f } * w
    drawCircle(Color(0xFFFFE680), h * 0.20f, Offset(sunX, h * 0.34f))
    drawCircle(Color(0xFFFFC107), h * 0.13f, Offset(sunX, h * 0.34f))
    val mar = h * 0.60f
    drawRect(Color(0xFF1AA3E0), Offset(0f, mar), Size(w, h - mar))
    repeat(12) {
        val x = r.nextFloat() * w * 0.9f
        val y = mar + (0.1f + r.nextFloat() * 0.5f) * (h - mar)
        drawLine(Color.White, Offset(x, y), Offset(x + w * 0.09f, y), strokeWidth = h * 0.012f)
    }
    val bx = w * (0.3f + 0.4f * r.nextFloat())
    val by = mar + h * 0.04f
    val vela = Path().apply {
        moveTo(bx, by - h * 0.17f)
        lineTo(bx + h * 0.09f, by)
        lineTo(bx, by)
        close()
    }
    drawPath(vela, Color.White)
    val casco = Path().apply {
        moveTo(bx - h * 0.05f, by)
        lineTo(bx + h * 0.12f, by)
        lineTo(bx + h * 0.09f, by + h * 0.035f)
        lineTo(bx - h * 0.02f, by + h * 0.035f)
        close()
    }
    drawPath(casco, Color(0xFFE8590C))
    val arena = Path().apply {
        moveTo(0f, h)
        lineTo(0f, h * 0.90f)
        quadraticBezierTo(w * 0.5f, h * 0.80f, w, h * 0.92f)
        lineTo(w, h)
        close()
    }
    drawPath(arena, Color(0xFFFFE0A3))
}

private fun DrawScope.arbol(x: Float, base: Float, s: Float, hoja: Color) {
    drawRect(Color(0xFF6D4C41), Offset(x - s * 0.06f, base - s * 0.6f), Size(s * 0.12f, s * 0.6f))
    drawCircle(hoja, s * 0.38f, Offset(x, base - s * 0.8f))
}

private fun DrawScope.otono(m0: Int, r: Random) {
    val w = size.width
    val h = size.height
    drawCircle(Color(0xFFFF9F43), h * 0.11f, Offset(w * 0.78f, h * 0.30f))
    colina(Color(0xFFE0A93F), h * 0.64f, 0.10f)
    colina(Color(0xFFC77D2E), h * 0.76f, -0.08f)
    val hojas = listOf(Color(0xFFE8590C), Color(0xFFF59F00), Color(0xFFC92A2A), Color(0xFFFFB84D))
    val n = 3 + (m0 - 2) * 2
    for (i in 0 until n) {
        val x = w * (0.08f + 0.84f * (i + 0.5f) / n)
        val base = h * (0.80f + 0.08f * r.nextFloat())
        arbol(x, base, h * (0.30f + 0.08f * r.nextFloat()), hojas[i % hojas.size])
    }
    repeat(14 + (m0 - 2) * 5) { i ->
        drawOval(
            hojas[i % hojas.size],
            Offset(r.nextFloat() * w, r.nextFloat() * h * 0.85f),
            Size(h * 0.024f, h * 0.013f)
        )
    }
}

private fun DrawScope.montana(x: Float, base: Float, ancho: Float, alto: Float, color: Color) {
    val p = Path().apply {
        moveTo(x - ancho / 2, base)
        lineTo(x, base - alto)
        lineTo(x + ancho / 2, base)
        close()
    }
    drawPath(p, color)
    val nieve = Path().apply {
        moveTo(x - ancho * 0.125f, base - alto * 0.75f)
        lineTo(x, base - alto)
        lineTo(x + ancho * 0.125f, base - alto * 0.75f)
        close()
    }
    drawPath(nieve, Color.White)
}

private fun DrawScope.pino(x: Float, base: Float, s: Float) {
    drawRect(Color(0xFF6D4C41), Offset(x - s * 0.03f, base - s * 0.12f), Size(s * 0.06f, s * 0.12f))
    val p = Path().apply {
        moveTo(x - s * 0.22f, base - s * 0.1f)
        lineTo(x, base - s)
        lineTo(x + s * 0.22f, base - s * 0.1f)
        close()
    }
    drawPath(p, Color(0xFF2E8B57))
    val tope = Path().apply {
        moveTo(x - s * 0.08f, base - s * 0.75f)
        lineTo(x, base - s)
        lineTo(x + s * 0.08f, base - s * 0.75f)
        close()
    }
    drawPath(tope, Color.White)
}

private fun DrawScope.invierno(m0: Int, r: Random) {
    val w = size.width
    val h = size.height
    drawCircle(Color.White, h * 0.08f, Offset(w * 0.2f, h * 0.28f))
    montana(w * 0.25f, h * 0.74f, w * 0.7f, h * 0.45f, Color(0xFF8FA9C4))
    montana(w * 0.72f, h * 0.74f, w * 0.8f, h * 0.55f, Color(0xFFA9BFD6))
    montana(w * 0.5f, h * 0.74f, w * 0.5f, h * 0.35f, Color(0xFF7F9BB8))
    colina(Color.White, h * 0.74f, 0.06f)
    val n = 3 + (m0 - 5)
    for (i in 0 until n) {
        val x = w * (0.08f + 0.84f * (i + 0.5f) / n)
        pino(x, h * (0.84f + 0.08f * r.nextFloat()), h * 0.30f)
    }
    repeat(25 + (m0 - 5) * 10) {
        drawCircle(
            Color.White,
            h * (0.004f + 0.006f * r.nextFloat()),
            Offset(r.nextFloat() * w, r.nextFloat() * h * 0.78f)
        )
    }
}

private fun DrawScope.tulipan(x: Float, base: Float, s: Float, color: Color) {
    val y = base - s
    drawLine(Color(0xFF2F9E44), Offset(x, base), Offset(x, y), strokeWidth = s * 0.06f)
    drawOval(Color(0xFF2F9E44), Offset(x, base - s * 0.45f), Size(s * 0.22f, s * 0.08f))
    val a = s * 0.16f
    val b = s * 0.26f
    val flor = Path().apply {
        moveTo(x - a, y)
        lineTo(x - a, y - b)
        lineTo(x - a / 2, y - b * 0.65f)
        lineTo(x, y - b)
        lineTo(x + a / 2, y - b * 0.65f)
        lineTo(x + a, y - b)
        lineTo(x + a, y)
        quadraticBezierTo(x, y + b * 0.6f, x - a, y)
        close()
    }
    drawPath(flor, color)
}

private fun DrawScope.primavera(m0: Int, r: Random) {
    val w = size.width
    val h = size.height
    drawCircle(Color(0xFFFFE680), h * 0.17f, Offset(w * 0.85f, h * 0.25f))
    drawCircle(Color(0xFFFFD43B), h * 0.11f, Offset(w * 0.85f, h * 0.25f))
    colina(Color(0xFF8CE06A), h * 0.62f, 0.10f)
    colina(Color(0xFF4CC25B), h * 0.74f, -0.06f)
    val colores = listOf(
        Color(0xFFFF4D8D), Color(0xFFFFD43B), Color(0xFFFF6B6B),
        Color(0xFFB35CFF), Color(0xFFFF9F43)
    )
    val n = 6 + (m0 - 8) * 3
    for (i in 0 until n) {
        val x = w * (0.05f + 0.9f * (i + 0.5f) / n)
        val base = h * (0.88f + 0.08f * r.nextFloat())
        tulipan(x, base, h * (0.26f + 0.12f * r.nextFloat()), colores[i % colores.size])
    }
}
