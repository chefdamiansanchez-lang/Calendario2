package com.datco.calendario

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

data class Event(
    val id: Long,
    val date: String,
    val hour: Int,
    val minute: Int,
    val title: String,
    val alarm: Boolean
) {
    fun dateTime(): LocalDateTime = LocalDate.parse(date).atTime(hour, minute)
    val code: Int get() = (id % Int.MAX_VALUE).toInt()
}

class EventStore(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("eventos", Context.MODE_PRIVATE)

    fun all(): List<Event> {
        val arr = JSONArray(prefs.getString("lista", "[]") ?: "[]")
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Event(
                o.getLong("id"),
                o.getString("date"),
                o.getInt("h"),
                o.getInt("m"),
                o.getString("title"),
                o.getBoolean("alarm")
            )
        }
    }

    private fun save(list: List<Event>) {
        val arr = JSONArray()
        list.forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("date", e.date)
                    .put("h", e.hour)
                    .put("m", e.minute)
                    .put("title", e.title)
                    .put("alarm", e.alarm)
            )
        }
        prefs.edit().putString("lista", arr.toString()).apply()
    }

    fun add(e: Event) {
        save(all() + e)
        Alarms.schedule(ctx, e)
    }

    fun remove(e: Event) {
        save(all().filter { it.id != e.id })
        Alarms.cancel(ctx, e)
    }
}

object Alarms {
    const val CHANNEL = "eventos_alarma"

    fun createChannel(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel(CHANNEL, "Alarmas de eventos", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(
            RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
        )
        ch.enableVibration(true)
        nm.createNotificationChannel(ch)
    }

    private fun pending(ctx: Context, e: Event, flags: Int): PendingIntent? {
        val intent = Intent(ctx, AlarmReceiver::class.java)
            .putExtra("title", e.title)
            .putExtra("hour", e.hour)
            .putExtra("minute", e.minute)
        return PendingIntent.getBroadcast(ctx, e.code, intent, flags or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(ctx: Context, e: Event) {
        if (!e.alarm) return
        val cuando = e.dateTime().atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
        if (cuando <= System.currentTimeMillis()) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val abrir = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val pi = pending(ctx, e, PendingIntent.FLAG_UPDATE_CURRENT) ?: return
        am.setAlarmClock(AlarmManager.AlarmClockInfo(cuando, abrir), pi)
    }

    fun cancel(ctx: Context, e: Event) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(ctx, e, PendingIntent.FLAG_NO_CREATE) ?: return
        am.cancel(pi)
        pi.cancel()
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Alarms.createChannel(ctx)
        val titulo = intent.getStringExtra("title") ?: "Evento"
        val hora = "%02d:%02d".format(intent.getIntExtra("hour", 0), intent.getIntExtra("minute", 0))
        val abrir = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(ctx, Alarms.CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(titulo)
            .setContentText("Evento de las $hora")
            .setContentIntent(abrir)
            .setCategory(Notification.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            EventStore(ctx).all().forEach { Alarms.schedule(ctx, it) }
        }
    }
}
