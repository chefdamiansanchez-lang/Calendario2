package com.datco.calendario

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun DatcoSplash(onDone: () -> Unit) {
    val progreso = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        progreso.animateTo(1f, tween(900))
        delay(1600)
        onDone()
    }

    val grisAzul = Color(0xFF9FB3C8)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF1B2028)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .alpha(progreso.value)
                .offset(y = ((1f - progreso.value) * 24f).dp)
        ) {
            Box(
                Modifier
                    .size(104.dp)
                    .clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) {
                Text("D", fontSize = 64.sp, fontWeight = FontWeight.Black, color = Color.White)
            }
            Spacer(Modifier.height(28.dp))
            Text(
                "DATCO",
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 10.sp,
                color = Color.White
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                fontSize = 11.sp,
                color = grisAzul,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más",
            fontSize = 13.sp,
            color = grisAzul,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp)
                .alpha(progreso.value)
        )
    }
}
