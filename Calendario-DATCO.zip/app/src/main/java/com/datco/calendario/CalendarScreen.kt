package com.datco.calendario

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.view.WindowCompat
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.YearMonth

val MESES = listOf(
    "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"
)
val DIAS = listOf("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
val DIAS_CORTOS = listOf("lu", "ma", "mi", "ju", "vi", "sá", "do")

val NAVY = Color(0xFF1F2A44)
val CREMA = Color(0xFFFFFBF2)
val GRIS = Color(0xFF6B7A90)
val GRIS_CLARO = Color(0xFFB8C2CF)

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun CalendarScreen() {
    val ctx = LocalContext.current
    val view = LocalView.current
    val store = remember { EventStore(ctx) }
    var events by remember { mutableStateOf(store.all()) }
    var ym by remember { mutableStateOf(YearMonth.now()) }
    var selected by remember { mutableStateOf<LocalDate?>(null) }
    var now by remember { mutableStateOf(LocalDateTime.now()) }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(5000)
        }
    }

    val m0 = ym.monthValue - 1
    val accent = acento(m0)
    val sky = SKY[m0]

    SideEffect {
        val w = ctx.findActivity()?.window
        if (w != null) {
            w.statusBarColor = sky.toArgb()
            w.navigationBarColor = CREMA.toArgb()
            val c = WindowCompat.getInsetsController(w, view)
            c.isAppearanceLightStatusBars = true
            c.isAppearanceLightNavigationBars = true
        }
    }

    val hoy = now.toLocalDate()
    val primero = ym.atDay(1)
    val desfase = primero.dayOfWeek.value - 1
    val inicio = primero.minusDays(desfase.toLong())
    val filas = (desfase + ym.lengthOfMonth() + 6) / 7
    val proximos = events.filter { it.dateTime() >= now }.sortedBy { it.dateTime() }.take(3)

    Box(Modifier.fillMaxSize().background(CREMA)) {
        Column(Modifier.fillMaxSize()) {
            Header(ym, now, { ym = ym.minusMonths(1) }, { ym = ym.plusMonths(1) })

            Column(
                Modifier
                    .weight(1f)
                    .offset(y = (-24).dp)
                    .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                    .background(CREMA)
                    .verticalScroll(rememberScrollState())
                    .padding(start = 12.dp, end = 12.dp, top = 16.dp, bottom = 90.dp)
            ) {
                Row(Modifier.fillMaxWidth()) {
                    DIAS_CORTOS.forEach { d ->
                        Text(
                            d,
                            Modifier.weight(1f),
                            color = GRIS,
                            fontSize = 14.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
                Spacer(Modifier.height(6.dp))
                for (f in 0 until filas) {
                    Row(Modifier.fillMaxWidth().height(50.dp), verticalAlignment = Alignment.CenterVertically) {
                        for (c in 0 until 7) {
                            val d = inicio.plusDays((f * 7 + c).toLong())
                            DayCell(
                                d = d,
                                enMes = d.month == ym.month,
                                esHoy = d == hoy,
                                punto = events.any { it.date == d.toString() },
                                accent = accent,
                                modifier = Modifier.weight(1f)
                            ) { selected = d }
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                if (proximos.isEmpty()) {
                    Text(
                        "Tocá un día para agregar un evento",
                        color = GRIS,
                        fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                } else {
                    Text(
                        "Próximos eventos",
                        color = NAVY,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    proximos.forEach { e ->
                        val fecha = LocalDate.parse(e.date)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { ym = YearMonth.from(fecha); selected = fecha }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.width(5.dp).height(36.dp).clip(RoundedCornerShape(3.dp)).background(accent))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(e.title, color = NAVY, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                Text(
                                    DIAS[fecha.dayOfWeek.value - 1].take(3) + " " + fecha.dayOfMonth +
                                        " · " + "%02d:%02d".format(e.hour, e.minute),
                                    color = GRIS,
                                    fontSize = 13.sp
                                )
                            }
                            if (e.alarm) Text("⏰", fontSize = 16.sp)
                        }
                    }
                }
            }
        }

        Box(
            Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(accent)
                .clickable { ym = YearMonth.now() }
                .padding(horizontal = 26.dp, vertical = 14.dp)
        ) {
            Text("Hoy", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        }

        selected?.let { d ->
            AgendaDialog(
                date = d,
                list = events.filter { it.date == d.toString() }.sortedBy { it.hour * 60 + it.minute },
                accent = accent,
                onAdd = { store.add(it); events = store.all() },
                onDelete = { store.remove(it); events = store.all() },
                onClose = { selected = null }
            )
        }
    }
}

@Composable
fun Header(ym: YearMonth, now: LocalDateTime, onPrev: () -> Unit, onNext: () -> Unit) {
    val m0 = ym.monthValue - 1
    Box(Modifier.fillMaxWidth().height(250.dp)) {
        Canvas(Modifier.fillMaxSize()) { drawScene(m0) }

        Column(
            Modifier.align(Alignment.TopCenter).padding(top = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                MESES[m0],
                fontSize = 40.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = NAVY
            )
            Text(estacion(m0) + " · " + ym.year, fontSize = 16.sp, color = NAVY)
        }

        CircleBtn("‹", Modifier.align(Alignment.TopStart).padding(16.dp), onPrev)
        CircleBtn("›", Modifier.align(Alignment.TopEnd).padding(16.dp), onNext)

        Row(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 38.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Text(
                "%02d:%02d".format(now.hour, now.minute),
                fontSize = 26.sp,
                fontFamily = FontFamily.Serif,
                fontWeight = FontWeight.Bold,
                color = NAVY
            )
            Spacer(Modifier.width(10.dp))
            Text(
                DIAS[now.dayOfWeek.value - 1] + " " + now.dayOfMonth,
                fontSize = 15.sp,
                color = GRIS,
                modifier = Modifier.padding(bottom = 3.dp)
            )
        }
    }
}

@Composable
fun CircleBtn(texto: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Color.White)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(texto, fontSize = 24.sp, color = NAVY)
    }
}

@Composable
fun DayCell(
    d: LocalDate,
    enMes: Boolean,
    esHoy: Boolean,
    punto: Boolean,
    accent: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(if (esHoy) accent else Color.Transparent)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center
        ) {
            Text(
                d.dayOfMonth.toString(),
                fontSize = 17.sp,
                fontWeight = if (esHoy) FontWeight.Bold else FontWeight.Medium,
                color = when {
                    esHoy -> Color.White
                    enMes -> NAVY
                    else -> GRIS_CLARO
                }
            )
            if (punto) {
                Box(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 4.dp)
                        .size(5.dp)
                        .clip(CircleShape)
                        .background(if (esHoy) Color.White else accent)
                )
            }
        }
    }
}

@Composable
fun AgendaDialog(
    date: LocalDate,
    list: List<Event>,
    accent: Color,
    onAdd: (Event) -> Unit,
    onDelete: (Event) -> Unit,
    onClose: () -> Unit
) {
    val ctx = LocalContext.current
    var titulo by remember { mutableStateOf("") }
    var hora by remember { mutableIntStateOf(9) }
    var minuto by remember { mutableIntStateOf(0) }
    var alarma by remember { mutableStateOf(true) }

    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxWidth(0.92f), shape = RoundedCornerShape(24.dp), color = Color.White) {
            Column(Modifier.padding(20.dp).verticalScroll(rememberScrollState())) {
                Text(
                    DIAS[date.dayOfWeek.value - 1] + " " + date.dayOfMonth + " de " +
                        MESES[date.monthValue - 1].lowercase(),
                    fontSize = 22.sp,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Bold,
                    color = NAVY
                )
                Spacer(Modifier.height(12.dp))

                if (list.isEmpty()) {
                    Text("Sin eventos este día", color = GRIS, fontSize = 15.sp)
                } else {
                    list.forEach { e ->
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "%02d:%02d".format(e.hour, e.minute),
                                color = accent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(e.title, Modifier.weight(1f), color = NAVY, fontSize = 16.sp)
                            if (e.alarm) Text("⏰", fontSize = 16.sp)
                            Text(
                                "✕",
                                color = GRIS,
                                fontSize = 18.sp,
                                modifier = Modifier.clickable { onDelete(e) }.padding(8.dp)
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = titulo,
                    onValueChange = { titulo = it },
                    label = { Text("Nuevo evento") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accent,
                        focusedLabelColor = accent,
                        cursorColor = accent
                    )
                )
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFEAF4FF))
                            .clickable {
                                TimePickerDialog(ctx, { _, h, m -> hora = h; minuto = m }, hora, minuto, true).show()
                            }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            "🕒 " + "%02d:%02d".format(hora, minuto),
                            color = NAVY,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    Spacer(Modifier.weight(1f))
                    Text("Alarma", color = NAVY, fontSize = 15.sp)
                    Spacer(Modifier.width(8.dp))
                    Switch(
                        checked = alarma,
                        onCheckedChange = { alarma = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.White)
                    )
                }
                Spacer(Modifier.height(14.dp))
                Button(
                    onClick = {
                        if (titulo.isNotBlank()) {
                            onAdd(Event(System.currentTimeMillis(), date.toString(), hora, minuto, titulo.trim(), alarma))
                            titulo = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = accent),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Agregar", color = Color.White, fontWeight = FontWeight.Bold)
                }
                TextButton(onClick = onClose, modifier = Modifier.align(Alignment.End)) {
                    Text("Cerrar", color = GRIS)
                }
            }
        }
    }
}
